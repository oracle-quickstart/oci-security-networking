## Copyright (c) 2025, Oracle and/or its affiliates.
## All rights reserved. The Universal Permissive License (UPL), Version 1.0 as shown at http://oss.oracle.com/licenses/upl

vcn_a_dns_label        = "vcna"

vcn_b_dns_label        = "vcnb"

vcn_a_ipv4_cidr_blocks = [
  "10.1.1.0/24",
  ]

vcn_b_ipv4_cidr_blocks = [
  "10.2.2.0/24",
  ]