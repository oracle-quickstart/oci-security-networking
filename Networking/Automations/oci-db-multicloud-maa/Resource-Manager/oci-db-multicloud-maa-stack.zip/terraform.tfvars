## Copyright (c) 2025, Oracle and/or its affiliates.
## All rights reserved. The Universal Permissive License (UPL), Version 1.0 as shown at http://oss.oracle.com/licenses/upl

vcn_primary_dns_label        = "vcnprimary"
vcn_primarytx_dns_label        = "vcnprimarytx"
vcn_standby_dns_label        = "vcnstandby"
vcn_dr_dns_label        = "vcndr"
vcn_drtx_dns_label        = "vcndrtx"

vcn_primary_ipv4_cidr_blocks = [
  "10.1.1.0/24",
  ]

# The transit VCN CIDR blocks can be any range, only used for provisining the VCN itself no subnets are needed within the VCN.
vcn_primarytx_ipv4_cidr_blocks = [
  "10.255.255.0/30",
  ]

vcn_standby_ipv4_cidr_blocks = [
  "10.2.2.0/24",
  ]

vcn_dr_ipv4_cidr_blocks = [
  "10.3.3.0/24",
  ]

# The transit VCN CIDR blocks can be any range, only used for provisining the VCN itself no subnets are needed within the VCN.
vcn_drtx_ipv4_cidr_blocks = [
  "10.255.255.0/30",
  ]